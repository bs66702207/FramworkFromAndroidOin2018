# BTstack Examples

The examples in this folder demonstrate how various Bluetooth profiles can be used with BTstack.

Each contains a btstack_main() function that is called after the Bluetooth stack has been configured.

By this, the examples are linked in by various ports in the port/ directory.
Please go to one of the subfolders of port/ to compile for a specific BTstack port.
