
Thanks for checking out BTstack! 

In this manual, we first provide a 'quick starter guide' for common platforms
before highlighting BTstack's main design choices and go over all implemented
protocols and profiles.

A series of examples show how BTstack can be used to implement common 
use cases. 

Finally, we outline the basic steps when integrating BTstack into existing 
single-threaded or even multi-threaded environments. 

