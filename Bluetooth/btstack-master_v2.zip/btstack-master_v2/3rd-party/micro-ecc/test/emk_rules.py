c, link = emk.module("c", "link")
link.depdirs += [
    "$:proj:$"
]
